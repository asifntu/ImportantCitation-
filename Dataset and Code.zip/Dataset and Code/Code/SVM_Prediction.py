import re
import pandas as pd
#from sklearn.externals \
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords

#model = pickle.load(open("finalized_model.sav","r"))

loaded_model = joblib.load('finalized_model_svm.sav')
checkdata = pd.read_csv("Faiza_data.csv",encoding='unicode-escape')
print(pd.notnull(checkdata['Citations']).dropna())
#checkdata['Citations'] = checkdata[checkdata["Citations"].notnull()]
#print(checkdata['Citations'])
#h = list (checkdata.loc[: , "Citations"])
#print (h)
#checkdata.head(1004).dropna()

REPLACE_BY_SPACE_RE = re.compile('[/(){}\[\]|@,;]')
BAD_SYMBOLS_RE = re.compile('[^0-9a-z #+_]')
STOPWORDS = set(stopwords.words('english'))

def clean_text(text):
    """
        text: a string
        return: modified initial string
    """
    if type(text) is str:
        text = text.lower()
        # lowercase text
        text = REPLACE_BY_SPACE_RE.sub(' ', text)  # replace REPLACE_BY_SPACE_RE symbols by space in text
        text = BAD_SYMBOLS_RE.sub('', text)  # delete symbols which are in BAD_SYMBOLS_RE from text
        text = ' '.join(word for word in text.split() if word not in STOPWORDS)  # delete stopwors from text
    return text
checkdata['Citations'] = checkdata['Citations'].apply(clean_text)
checkdata['Citations']= checkdata.Citations.fillna('')
print (checkdata['Citations'])
X= checkdata['Citations']
#for z in counts:
   #print (z)
prediction = loaded_model.predict(X)
print (prediction)
#checkdata['SVM_pred'] = prediction
#df = pd.read_csv('Data_set.csv',encoding='unicode-escape')

#checkdata.to_csv('Data_set.csv')
#print (checkdata['SVM_pred'])
#a= checkdata.SVM_pred.value_counts()
#print (a)