import pandas as pd
from sklearn import datasets, linear_model
from sklearn.model_selection import train_test_split
from matplotlib import pyplot as plt
from sklearn.metrics import precision_recall_fscore_support, accuracy_score

df = pd.read_csv("D:\check\in ex freq\ValenzuelaAnnotations.csv")
r = df.iloc[:, 3:4].values
dd = df.iloc[:, 6:11].values





X_train, X_test, y_train, y_test = train_test_split(dd, r, test_size=0.4 , random_state=83)






print(X_train.shape, y_train.shape)
print(X_test.shape, y_test.shape)

reg = linear_model.LinearRegression()


reg.fit(X_train , y_train)

print(reg.coef_)

print(X_test)
print(reg.intercept_)



print(reg.coef_[0][0])
print(reg.coef_[0][1])
print(reg.coef_[0][2])
print(reg.coef_[0][3])
print(reg.coef_[0][4])

#=============== for train===================


#
r1 = reg.coef_[0][0]
r2 = reg.coef_[0][1]
r3 = reg.coef_[0][2]
r4 = reg.coef_[0][3]
r5 = reg.coef_[0][4]
#
#
#
#
a = []
for k in y_train:

 if (k == 1):
  a.append(1)
 else:
  a.append(0)

filename = "D:\check\in ex freq\show.csv"
f = open(filename, "w")
header = "sum\n"
f.write(header)

for k in X_train:
    val1 = k[0]
    val2 = k[1]
    val3 = k[2]
    val4 = k[3]
    val5 = k[4]
    sum = r1 * val1 + r2 * val2 + r3 * val3 + r4 * val4 + r5 * val5 + reg.intercept_[0]
    f.write(str(sum) + '\n')
f.close()
dat = pd.read_csv('D:\check\in ex freq\show.csv')
d2 = dat.loc[:, "sum"]

print("maximum is")
print(max(d2))

print("minimum is")
print(min(d2))


wh = min(d2)


maxf = 0
sublimi = 0
prese = 0
rec = 0
accu = 0



while (wh < max(d2)):
  a2 = []

  for k2 in d2:

   if k2 > wh:
    a2.append(1)
   else:
    a2.append(0)


  accuracy = accuracy_score(a2, a)
  precision, recall, f1_score, _ = precision_recall_fscore_support(a2, a, average='binary')

  print("Accuracy: ", accuracy)
  print("Precision: ", precision)
  print("Recall: ", recall)
  print("F1 score: ", f1_score)
  print(" ")
  print(" ")
  if f1_score > maxf:
   maxf = f1_score
   sublimi = wh
   prese = precision
   rec = recall
   accu = accuracy
  wh = wh + 0.001

print("for training")
print(" maximum is ", maxf)
print(" maximum is on sublimi", sublimi)
print(" maximum is precision ", prese)
print(" maximum is recall ", rec)
print(" maximum is acuurac ", accu)


#==================================== for testing ==============================================



sum1 = 0
a = []
for k in y_test:

 if (k == 1):
  a.append(1)
 else:
  a.append(0)

filename1 = "D:\check\in ex freq\showtest.csv"
f12 = open(filename1, "w")
header12 = "sum\n"
f12.write(header12)

for k in X_test:
    val01 = k[0]
    val02 = k[1]
    val03 = k[2]
    val04 = k[3]
    val05 = k[4]
    sum1 = r1 * val01 + r2 * val02 + r3 * val03 + r4 * val04 + r5 * val05 + reg.intercept_[0]
    f12.write(str(sum1) + '\n')
f12.close()
dato = pd.read_csv('D:\check\in ex freq\showtest.csv')
d20 = dato.loc[:, "sum"]

print("maximum is")
print(max(d20))

print("minimum is")
print(min(d20))




a2 = []

for k2 in d20:

   if k2 > sublimi:
    a2.append(1)
   else:
    a2.append(0)


accuracy1 = accuracy_score(a2, a)
precision1, recall1, f1_score1, _ = precision_recall_fscore_support(a2, a, average='binary')

print("for testing ")
print("Accuracy: ", accuracy1)
print("Precision: ", precision1)
print("Recall: ", recall1)
print("F1 score: ", f1_score1)
print (" ")
print (" ")
