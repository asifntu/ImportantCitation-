import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
import nltk
nltk.download('stopwords')
nltk.download('punkt')
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score,confusion_matrix, classification_report, f1_score, precision_score, recall_score
import pandas as pd
import _pickle as cPickle
from nltk.stem.porter import *
#from sklearn.externals \
import joblib
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.svm import LinearSVC
from sklearn.svm import SVC




#data=pd.read_csv("G:\Data\Trained_Dataset.csv")
#data.head()
#data.info()
#a= data.Sentiment.value_counts()
#print (a)

df = pd.read_csv("Trained_DatasetNew.csv",encoding='unicode-escape')
#df = df[pd.notnull(df['Sentiment'])]
df['Sentiment'] = df.Sentiment.map({'o': 1, 'p': 2, 'n': 0})
print(df.head(10))
print (pd.notnull(df['Citation_Text']))

REPLACE_BY_SPACE_RE = re.compile('[/(){}\[\]\|@,;]')
BAD_SYMBOLS_RE = re.compile('[^0-9a-z #+_]')
STOPWORDS = stopwords.words('english')

def clean_text(text):
    """
        text: a string
        return: modified initial string
    """
    text = text.lower()  # lowercase text
    text = REPLACE_BY_SPACE_RE.sub(' ', text)  # replace REPLACE_BY_SPACE_RE symbols by space in text
    text = BAD_SYMBOLS_RE.sub('', text)  # delete symbols which are in BAD_SYMBOLS_RE from text
    text = ' '.join(word for word in text.split() if word not in STOPWORDS)  # delete stopwors from text
    from nltk.tokenize import sent_tokenize, word_tokenize
    def stemSentence(text):
        porter = PorterStemmer()
        token_words = word_tokenize(text)
        stem_sentence = []
        for word in token_words:
            stem_sentence.append(porter.stem(word))
            stem_sentence.append(" ")
        return "".join(stem_sentence)
    text = stemSentence(text)
    return text
df['Citation_Text'] = df['Citation_Text'].apply(clean_text)
df['Citation_Text'].apply(lambda x: len(x.split(' '))).sum()

X_train = df.Citation_Text
y_train= df.Sentiment

X_train, X_test, y_train, y_test = train_test_split(X_train, y_train, test_size=30, random_state=0)

sv = Pipeline([('Vect', TfidfVectorizer(max_df=2, min_df=1, max_features=5000, stop_words='english',ngram_range=(1, 1))),
               ('tfidf', TfidfTransformer()),
               ('clf', LinearSVC(class_weight='balanced', C=1.0, random_state=0)),
              ])
scores = cross_val_score(sv, X_train, y_train, cv=10, scoring='accuracy')
sv.fit(X_train, y_train)
print("Score", scores)
print("Mean Score",scores.mean())
print("Standard_deviation", scores.std())

filename = 'finalized_model_svm.sav'
joblib.dump(sv, filename)
print ("save")